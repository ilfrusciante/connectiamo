export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Benvenuto su Connectiamo</h1>
      <p>La piattaforma per connettere segnalatori e professionisti.</p>
    </div>
  );
}
